//
// Created by siebe on 20/02/2022.
//

#ifndef TA_DFA_H
#define TA_DFA_H

#include <iostream>
#include <vector>

using namespace std;

class DFAState;

class DFA {
    vector<DFAState*> states;
    DFAState* currentState;
    string alphabet;
public:

    DFA();

    DFA(string file);

    DFA(DFA dfa1, DFA dfa2, bool doorsnede);

    bool accepts(const string&);

    const string &getAlphabet() const;

    void setAlphabet(const string &Alphabet);

    void addState(DFAState* state);

    void removeState(DFAState* state);

    DFAState* findStateByName(const string& name);

    const vector<DFAState *> &getStates() const;

    void print();

    string toRgex(string current, string even);

    //RE toRE();
};


#endif //TA_DFA_H
