//
// Created by siebe on 1/04/2022.
//

#include "DFA.h"
#include "NFAState.h"
#include "DFAState.h"

NFAState::NFAState(NFA* nfa, const string &name, bool final, bool starting) : nfa(nfa), name(name), final(final), starting(starting) {}

bool NFAState::isFinal() const {
    return final;
}

void NFAState::setFinal(bool final) {
    NFAState::final = final;
}

vector<pair<char, NFAState*>> NFAState::getTransitions() {
    return transitions;
}

void NFAState::setTransitions(vector<pair<char, NFAState*>> transitions) {
    NFAState::transitions = transitions;
}

void NFAState::addTransition(const char& str, NFAState* dest) {
    transitions.push_back(make_pair(str, dest));
}


vector<NFAState*> NFAState::seeDestinations(char str) {
    vector<NFAState*> dests;
    for (auto tra : transitions) {
        if (tra.first == str) {
            dests.push_back(tra.second);
        }
    }
    return dests;
}

const string &NFAState::getName() const {
    return name;
}

void NFAState::setName(const string &name) {
    NFAState::name = name;
}

vector<pair<char, NFAState*>> NFAState::getTransition(char input) {
    vector<pair<char, NFAState*>> tras;
    for (auto tra : transitions) {
        if (tra.first == input) {
            tras.push_back(tra);
        }
    }
    return tras;
}

bool NFAState::isStarting() const {
    return starting;
}

DFAState *NFAState::convert(DFA* dfa) {
    DFAState* state = new DFAState(dfa, name, final, starting);
    /*
    for (auto c : dfa->getAlphabet()) {
        if (seeDestinations(c).size() == 0) {
            state->addTransition(c, state);
        } else {
            bool startYes = false;
            bool finalYes = false;
            string newName = "";
            for (auto sta : seeDestinations(c)) {
                if (sta->isFinal()) {finalYes = true;}
                if (sta->isStarting()) {startYes = true;}
                newName += sta->getName();
            }
            DFAState* destState = new DFAState(dfa, newName, finalYes, startYes);
            state->addTransition(c, destState);
        }
    }
    */
    return state;
}

NFA *NFAState::getNfa() const {
    return nfa;
}
