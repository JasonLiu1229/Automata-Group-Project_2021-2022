//
// Created by siebe on 20/02/2022.
//

#include "DFA.h"
#include <algorithm>
#include <map>
#include "DFAState.h"
#include <fstream>
#include <iomanip>
#include "json.hpp"
#include <sstream>

using json = nlohmann::json;

DFA::DFA() {
    /*
    DFAState* Q0 = new DFAState("Q0",true);
    DFAState* Q1 = new DFAState("Q1",false);
    DFAState* Q2 = new DFAState("Q2",false);
    Q0->addTransition('0',Q0);
    Q0->addTransition('1',Q1);
    Q1->addTransition('0',Q2);
    Q1->addTransition('1',Q0);
    Q2->addTransition('0',Q1);
    Q2->addTransition('1',Q2);
    states.push_back(Q0);
    states.push_back(Q1);
    states.push_back(Q2);
    currentState = Q0;
    alphabet = "01";
    */
}

bool DFA::accepts(const string& str) {
    for (auto c : str) {
        if(find(alphabet.begin(), alphabet.end(),c) != alphabet.end()) {
            currentState = currentState->seeDestination(c);
        } else {return false;}
    }
    if (currentState->isFinal()) {
        return true;
    }
    return false;
}

const string &DFA::getAlphabet() const {
    return alphabet;
}

void DFA::setAlphabet(const string &alphabet) {
    DFA::alphabet = alphabet;
}

DFA::DFA(string file) {
    ifstream input(file);
    json j;
    input >> j;
    for (auto c : j["alphabet"]) {
        alphabet += c;
    }
    for (auto s : j["states"]) {
        DFAState* state = new DFAState(this, s["name"], s["accepting"], s["starting"]);
        states.push_back(state);
        if (s["starting"]) {
            currentState = state;
        }
    }
    for (auto state : states) {
        for (auto t : j["transitions"]) {
            if (t["from"] == state->getName()) {
                for (auto destState : states) {
                    if (t["to"] == destState->getName()) {
                        for (auto c : alphabet) {
                            for (char d : to_string(t["input"])) {
                                if (c == d) {state->addTransition(c,destState);}
                            }
                        }
                    }
                }
            }
        }
    }
}

void DFA::addState(DFAState* state) {
    states.push_back(state);
}

DFAState* DFA::findStateByName(const string& name) {
    for (auto state : states) {
        if (state->getName() == name) {
            return state;
        }
    }
    return nullptr;
}

void DFA::print() {
    json j;
    j["type"] = "DFA";
    for (auto c : alphabet) {
        string s(1, c);
        j["alphabet"].push_back(s);
    }
    int i = 0;
    for (auto state : states) {
        j["states"].push_back({});
        j["states"][i]["name"] = state->getName();
        i++;
    }
    sort(j["states"].begin(), j["states"].end());
    for (auto state : states) {
        for (int i = 0; i < j["states"].size(); i++) {
            if (state->getName() == j["states"][i]["name"]) {
                j["states"][i]["starting"] = state->isStarting();
                j["states"][i]["accepting"] = state->isFinal();
            }
        }
    }
    i = 0;
    for (auto state : states) {
        for (auto tra : state->getTransitions()) {
            j["transitions"].push_back({});
            j["transitions"][i]["from"] = state->getName();
            j["transitions"][i]["to"] = tra.second->getName();
            string s(1, tra.first);
            j["transitions"][i]["input"] = s;
            i++;
        }
    }
    sort(j["transitions"].begin(), j["transitions"].end());
    cout << setw(4) << j << endl;
}

const vector<DFAState *> &DFA::getStates() const {
    return states;
}

void DFA::removeState(DFAState* state) {
    states.erase(find(states.begin(), states.end(), state));
}

DFA::DFA(DFA dfa1, DFA dfa2, bool doorsnede) {
    alphabet = dfa1.getAlphabet();
    for (auto state1 : dfa1.getStates()) {
        if (state1->isStarting()) {
            for (auto state2 : dfa2.getStates()) {
                if (state2->isStarting()) {
                    bool fin = (doorsnede and state1->isFinal() and state2->isFinal()) or (!doorsnede and (state1->isFinal() or state2->isFinal()));
                    DFAState* state = new DFAState(this, "("+state1->getName()+","+state2->getName()+")", fin, true);
                    addState(state);
                }
            }
        }
    }
    bool ready = false;
    while (!ready) {
        ready = true;
        vector<DFAState*> dfaStateCopy = states;
        for (auto DState : dfaStateCopy) {
            stringstream ss(DState->getName());
            ///Code below is taken from https://stackoverflow.com/a/10861816
            vector<string> stateNames;
            while (ss.good()) {
                string substr;
                getline(ss, substr, ',');
                stateNames.push_back(substr);
            }
            //End of copied code
            for (auto c : alphabet) {
                string destName = "(";
                bool destFin1 = false;
                bool destFin2 = false;
                for (auto state1 : dfa1.getStates()) {
                    if (stateNames[0] == "("+state1->getName()) {
                        destName += state1->seeDestination(c)->getName();
                        if (state1->seeDestination(c)->isFinal()) { destFin1 = true; }
                    }
                }
                destName += ",";
                for (auto state2 : dfa2.getStates()) {
                    if (stateNames[1] == state2->getName()+")") {
                        destName += state2->seeDestination(c)->getName();
                        if (state2->seeDestination(c)->isFinal()) { destFin2 = true; }
                    }
                }
                destName += ")";
                bool destFin = (doorsnede and destFin1 and destFin2) or (!doorsnede and (destFin1 or destFin2));
                if (findStateByName(destName) != nullptr) {
                    DState->addTransition(c, findStateByName(destName));
                } else {
                    DFAState* newState = new DFAState(this, destName, destFin, false);
                    addState(newState);
                    ready = false;
                    DState->addTransition(c, newState);
                }
            }
        }
    }
}
