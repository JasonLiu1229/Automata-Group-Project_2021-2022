//
// Created by siebe on 26/02/2022.
//

#include <iostream>
#include "DFAState.h"
#include "DFA.h"

DFAState::DFAState(DFA* dfa, const string &name, bool final, bool starting) : dfa(dfa), name(name), final(final), starting(starting) {}

bool DFAState::isFinal() const {
    return final;
}

void DFAState::setFinal(bool final) {
    DFAState::final = final;
}

vector<pair<char, DFAState*>> DFAState::getTransitions() {
    return transitions;
}

void DFAState::setTransitions(vector<pair<char, DFAState*>> transitions) {
    DFAState::transitions = transitions;
}

void DFAState::addTransition(const char& str, DFAState *dest) {
    for (auto it = transitions.begin(); it != transitions.end();) {
        if (it->first == str) {
            it = transitions.erase(it);
            break;
        } else {it++;}
    }
    transitions.push_back(make_pair(str, dest));
}

DFAState* DFAState::seeDestination(char str) {
    for (auto tra : transitions) {
        if (tra.first == str) {
            return tra.second;
        }
    }
}

const string &DFAState::getName() const {
    return name;
}

void DFAState::setName(const string &name) {
    DFAState::name = name;
}

bool DFAState::isStarting() const {
    return starting;
}

DFA *DFAState::getDfa() const {
    return dfa;
}
