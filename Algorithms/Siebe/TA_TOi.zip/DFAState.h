//
// Created by siebe on 26/02/2022.
//

#ifndef TA_DFASTATE_H
#define TA_DFASTATE_H

#include <iostream>
#include <vector>

using namespace std;

class NFAState;
class DFA;

class DFAState {
    DFA* dfa;
    string name;
    vector<pair<char, DFAState*>> transitions;
    bool final = false;
    bool starting = false;
public:

    DFAState(DFA* dfa, const string &name, bool final, bool starting);

    DFA *getDfa() const;

    const string &getName() const;

    void setName(const string &name);

    vector<pair<char, DFAState*>>getTransitions();

    void setTransitions(vector<pair<char, DFAState*>> transitions);

    void addTransition(const char& str,DFAState* dest);

    DFAState* seeDestination(char str);

    bool isStarting() const;

    bool isFinal() const;

    void setFinal(bool final);
};


#endif //TA_DFASTATE_H
