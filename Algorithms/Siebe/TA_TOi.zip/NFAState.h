//
// Created by siebe on 1/04/2022.
//

#ifndef TA_NFASTATE_H
#define TA_NFASTATE_H

#include <iostream>
#include <vector>

using namespace std;

class DFA;
class NFA;
class DFAState;

class NFAState {
    NFA* nfa;
    string name;
    vector<pair<char, NFAState*>> transitions;
    bool final = false;
    bool starting = false;
public:

    NFAState(NFA* nfa, const string &name, bool final, bool starting);

    NFA *getNfa() const;

    const string &getName() const;

    void setName(const string &name);

    vector<pair<char, NFAState*>> getTransitions();

    void setTransitions(vector<pair<char, NFAState*>> transitions);

    void addTransition(const char&, NFAState*);

    vector<pair<char, NFAState*>> getTransition(char input);

    vector<NFAState*> seeDestinations(char str);

    bool isFinal() const;

    bool isStarting() const;

    void setFinal(bool final);

    DFAState* convert(DFA* dfa);
};

#endif //TA_NFASTATE_H
