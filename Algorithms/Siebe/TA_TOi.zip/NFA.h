//
// Created by siebe on 29/03/2022.
//

#ifndef TA_NFA_H
#define TA_NFA_H

#include <iostream>
#include <vector>
#include "DFA.h"

using namespace std;

class NFAState;

class NFA {
    vector<NFAState*> states;
    vector<NFAState*> currentStates;
    NFAState* startingState;
    string alphabet;
public:
    NFA();

    NFA(string file);

    bool accepts(const string& input);

    const string &getAlphabet() const;

    void setAlphabet(const string &Alphabet);

    void addState(NFAState* state);

    DFA toDFA();
};


#endif //TA_NFA_H
