//
// Created by siebe on 29/03/2022.
//

#include "NFA.h"
#include <algorithm>
#include <map>
#include "NFAState.h"
#include <fstream>
#include <iomanip>
#include <set>
#include "json.hpp"
#include "DFA.h"
#include "DFAState.h"

using json = nlohmann::json;

NFA::NFA() {

}

NFA::NFA(string file) {
    ifstream input(file);
    json j;
    input >> j;
    for (auto c : j["alphabet"]) {
        alphabet += c;
    }
    for (auto s : j["states"]) {
        NFAState* state = new NFAState(this, s["name"], s["accepting"], s["starting"]);
        states.push_back(state);
        if (s["starting"]) {
            currentStates.push_back(state);
            startingState = state;
        }
    }
    for (auto state : states) {
        for (auto t : j["transitions"]) {
            if (t["from"] == state->getName()) {
                for (auto destState : states) {
                    if (t["to"] == destState->getName()) {
                        state->addTransition(to_string(t["input"])[1], destState);
                    }
                }
            }
        }
    }
}

bool NFA::accepts(const string& str) {
    currentStates.clear();
    currentStates.push_back(startingState);
    for (auto c : str) {
        if(find(alphabet.begin(), alphabet.end(),c) != alphabet.end()) {
            vector<NFAState*> newCurrentStates;
            for (auto state : currentStates) {
                for (auto dest : state->seeDestinations(c)) {
                    newCurrentStates.push_back(dest);
                }
            }
            currentStates = newCurrentStates;
        } else {return false;}
    }
    for (auto state : currentStates) {
        if (state->isFinal()) {
            return true;
        }
    }
    return false;
}

const string &NFA::getAlphabet() const {
    return alphabet;
}

void NFA::setAlphabet(const string &alphabet) {
    NFA::alphabet = alphabet;
}

DFA NFA::toDFA() {
    DFA dfa;
    dfa.setAlphabet(alphabet);

    for (auto state : states) {
        if (state->isStarting()) {
            dfa.addState(new DFAState(&dfa, "{"+state->getName()+"}", state->isFinal(), state->isStarting()));
        }
    }
    bool ready = false;
    while (!ready) {
        ready = true;
        vector<DFAState*> dfaStateCopy = dfa.getStates();
        for (auto DState : dfaStateCopy) {
            for (auto c : alphabet) {
                set<string> destName;
                bool destFin = false;
                for (auto NState : states) {
                    if (DState->getName() == "{"+NState->getName()+"}" or strstr(DState->getName().c_str(), NState->getName().c_str())) {
                        for (auto state: NState->seeDestinations(c)) {
                            destName.insert(state->getName());
                            if (state->isFinal()) { destFin = true; }
                        }
                    }
                }
                string realDestName = "{";
                for (const auto& s : destName) {
                    if (find(destName.begin(), destName.end(), s) != prev(destName.end())) {
                        realDestName += s;
                        realDestName += ",";
                    } else {
                        realDestName += s;
                    }
                }
                realDestName += "}";
                if (dfa.findStateByName(realDestName) != nullptr) {
                    DState->addTransition(c, dfa.findStateByName(realDestName));
                } else {
                    DFAState* newState = new DFAState(&dfa, realDestName, destFin, false);
                    dfa.addState(newState);
                    ready = false;
                    DState->addTransition(c, newState);
                }
            }
        }
    }
    vector<DFAState*> dfaStateCopy = dfa.getStates();
    for (auto DState : dfaStateCopy) {
        for (auto c : alphabet) {
            set<string> destName;
            for (auto NState : states) {
                if (DState->getName() == "{"+NState->getName()+"}" or strstr(DState->getName().c_str(), NState->getName().c_str())) {
                    for (auto state: NState->seeDestinations(c)) {
                        destName.insert(state->getName());
                    }
                }
            }
            string realDestName = "{";
            for (const auto& s : destName) {
                if (find(destName.begin(), destName.end(), s) != prev(destName.end())) {
                    realDestName += s;
                    realDestName += ",";
                } else {
                    realDestName += s;
                }
            }
            realDestName += "}";
            DState->addTransition(c, dfa.findStateByName(realDestName));
        }
    }
    return dfa;
}

void NFA::addState(NFAState *state) {
    states.push_back(state);
}